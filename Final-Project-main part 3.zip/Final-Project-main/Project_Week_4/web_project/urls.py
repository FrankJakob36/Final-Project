from django.contrib import admin
from django.urls import path
from my_app.views import default_greet, second_page, login_page, logout_view, signup_page

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', default_greet, name='home'),           # http://127.0.0.1:8000/
    path('second/', second_page, name='second_page'),  # http://127.0.0.1:8000/second/
    path('login/', login_page, name='login_page'),         # Login page
    path('logout/', logout_view, name='logout'),     # Logout page
    path('signup/', signup_page, name='signup')     # Uncomment if you add a signup page
]
