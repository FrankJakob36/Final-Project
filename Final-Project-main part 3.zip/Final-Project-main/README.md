# Final-Project
This is gonna be a cool little msuic app I make using django :) for a class